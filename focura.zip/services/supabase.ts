
import { createClient } from '@supabase/supabase-js';

// These would normally be provided by the environment
// We use descriptive placeholders to trigger the "Demo Mode" fallback in the Auth component
const supabaseUrl = (window as any)._env_?.SUPABASE_URL || 'https://MISSING_PROJECT.supabase.co';
const supabaseAnonKey = (window as any)._env_?.SUPABASE_ANON_KEY || 'MISSING_KEY';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
