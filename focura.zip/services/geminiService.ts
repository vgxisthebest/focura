
import { GoogleGenAI, Type } from "@google/genai";
import { Task } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAISuggestions = async (existingTasks: Task[]): Promise<Partial<Task>[]> => {
  const unfinishedTasks = existingTasks.filter(t => !t.completed).map(t => t.title);
  const prompt = unfinishedTasks.length > 0 
    ? `I am currently working on: ${unfinishedTasks.join(', ')}. Based on this, suggest 3 highly actionable, high-impact tasks to help me finish the day strong. Be specific and concise.`
    : `I have no current tasks. Suggest 3 foundational high-performance habits or professional tasks to start a "Win Day" routine.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ['low', 'medium', 'high'] },
              category: { type: Type.STRING }
            },
            required: ['title', 'priority', 'category']
          }
        },
        systemInstruction: "You are Focura AI, a world-class productivity coach. You provide short, high-impact task suggestions that focus on deep work and meaningful results."
      }
    });

    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Focura AI Error:", error);
    return [];
  }
};

export interface FocusRecommendation {
  taskId: string;
  reason: string;
  suggestedDuration: number;
}

export const getBestFocusTask = async (
  tasks: Task[], 
  currentEnergy: 'low' | 'medium' | 'high',
  timeAvailable: number
): Promise<FocusRecommendation | null> => {
  const activeTasks = tasks.filter(t => !t.completed);
  if (activeTasks.length === 0) return null;

  const context = activeTasks.map(t => 
    `- ${t.title} | ID: ${t.id} | Priority: ${t.priority} | Est: ${t.estimated_time}m | Energy Req: ${t.energy_level}`
  ).join('\n');

  const prompt = `
    User Context:
    Energy: ${currentEnergy}
    Time Available: ${timeAvailable} minutes
    
    Tasks:
    ${context}

    Analyze the tasks and user context. Pick the single best task to work on NOW to maximize "winning the day".
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            taskId: { type: Type.STRING, description: "The ID of the recommended task from the provided list" },
            reason: { type: Type.STRING, description: "One sentence explaining why this is the best move" },
            suggestedDuration: { type: Type.NUMBER, description: "Recommended focus duration in minutes" }
          },
          required: ['taskId', 'reason', 'suggestedDuration']
        },
        systemInstruction: "You are Focura OS. You analyze user task lists and provide the most strategic next move based on priority, energy levels, and time constraints. Be decisive."
      }
    });

    return JSON.parse(response.text || 'null');
  } catch (error) {
    console.error("Focus Engine Error:", error);
    return null;
  }
};
