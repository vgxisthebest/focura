
import React, { useState } from 'react';
import { supabase } from '../services/supabase';

export const Auth: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Basic validation
    if (!email || !password) {
      setError("Please enter both email and password.");
      setLoading(false);
      return;
    }

    try {
      if (isSignUp) {
        const { error: signUpError } = await supabase.auth.signUp({ 
          email, 
          password,
          options: {
            data: { plan: 'free' }
          }
        });
        if (signUpError) throw signUpError;
        alert('Protocol Initiated. Check your email for authentication.');
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) throw signInError;
      }
    } catch (err: any) {
      console.error("Auth Error:", err);
      
      // If project is unconfigured or credentials are placeholders
      const isUnconfigured = 
        err.message?.includes('placeholder') || 
        err.message?.includes('MISSING') || 
        err.message?.includes('FetchError') ||
        err.message?.includes('project not found') ||
        err.message?.includes('Invalid URL');

      if (isUnconfigured) {
        setError("Supabase Project Not Linked. Initiating Demo Mode...");
        setTimeout(() => {
          const fakeSession = { 
            user: { 
              id: 'demo-user-' + Math.random().toString(36).substr(2, 9), 
              email: email || 'operator@focura.io' 
            },
            access_token: 'demo-token'
          };
          localStorage.setItem('focura_demo_session', JSON.stringify(fakeSession));
          window.location.reload();
        }, 1500);
      } else {
        setError(err.message || "Authentication failed. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-[#020617]">
      <div className="hidden lg:flex flex-col justify-center p-20 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_30%,rgba(79,70,229,0.1)_0%,transparent_50%)]"></div>
        <div className="relative z-10">
          <h1 className="text-8xl font-black italic tracking-tighter focura-gradient mb-6 uppercase">Focura</h1>
          <p className="text-2xl text-slate-400 font-light max-w-md leading-relaxed mb-12">
            The high-performance OS for elite productivity. <span className="text-white font-bold">Know what to do. Focus. Win your day.</span>
          </p>
          
          <div className="space-y-8">
            <FeatureItem 
              icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
              title="AI Focus Engine"
              desc="Deep analysis of your energy, deadlines, and priorities to pick your next move."
            />
            <FeatureItem 
              icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
              title="Tactical Timer"
              desc="Scientific Pomodoro intervals integrated directly into your protocol stream."
            />
            <FeatureItem 
              icon={<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
              title="Daily Performance"
              desc="Real-time score tracking. Compete with your yesterday's self."
            />
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center p-6 relative">
        <div className="glass-heavy max-w-md w-full p-10 lg:p-12 rounded-[3rem] shadow-2xl border-white/5 relative">
          <div className="scanline"></div>
          <div className="text-center mb-10">
            <h2 className="text-2xl font-black tracking-tight text-white mb-1 uppercase">
              {isSignUp ? 'Create Operator' : 'Authenticate'}
            </h2>
            <p className="text-slate-500 text-[10px] uppercase font-bold tracking-[0.3em]">System Initialization Required</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-6">
            {error && (
              <div className={`border text-xs p-4 rounded-2xl flex items-center gap-3 animate-pulse ${error.includes('Demo') ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400' : 'bg-rose-500/10 border-rose-500/20 text-rose-400'}`}>
                <svg className="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                {error}
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-[10px] uppercase font-black text-slate-500 tracking-[0.2em] ml-1">Command Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-900/80 border border-white/5 rounded-2xl px-6 py-4 focus:outline-none focus:border-indigo-500/50 transition-all text-white placeholder:text-slate-700 font-medium"
                placeholder="commander@focura.io"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase font-black text-slate-500 tracking-[0.2em] ml-1">Security Key</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-900/80 border border-white/5 rounded-2xl px-6 py-4 focus:outline-none focus:border-indigo-500/50 transition-all text-white placeholder:text-slate-700 font-medium"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-5 rounded-[1.5rem] transition-all shadow-xl shadow-indigo-600/20 active:scale-[0.98] disabled:opacity-50 text-sm uppercase tracking-widest flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>Syncing...</span>
                </>
              ) : (
                isSignUp ? 'Begin Mission' : 'Login to Command'
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-slate-500 text-[10px] font-black uppercase tracking-widest hover:text-white transition-colors border-b border-transparent hover:border-indigo-500 pb-1"
            >
              {isSignUp ? 'Existing Protocol? Login' : "New Operator? Create Protocol"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const FeatureItem = ({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) => (
  <div className="flex gap-6 items-start group">
    <div className="p-4 rounded-2xl bg-indigo-600/10 text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-500">
      {icon}
    </div>
    <div>
      <h3 className="text-lg font-black text-white mb-1 group-hover:text-indigo-400 transition-colors">{title}</h3>
      <p className="text-slate-500 text-sm font-medium leading-relaxed max-w-xs">{desc}</p>
    </div>
  </div>
);
