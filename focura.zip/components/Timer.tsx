
import React, { useState, useEffect, useCallback } from 'react';
import { TimerMode, Task } from '../types';

interface TimerProps {
  activeTask: Task | null;
  onSessionComplete: (duration: number, taskId: string | null) => void;
}

const Timer: React.FC<TimerProps> = ({ activeTask, onSessionComplete }) => {
  const [mode, setMode] = useState<TimerMode>(TimerMode.WORK);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);

  const toggleTimer = () => setIsActive(!isActive);

  const resetTimer = useCallback(() => {
    setIsActive(false);
    setTimeLeft(mode === TimerMode.WORK ? 25 * 60 : 5 * 60);
  }, [mode]);

  useEffect(() => {
    let interval: number | undefined;

    if (isActive && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      if (mode === TimerMode.WORK) {
        onSessionComplete(25, activeTask?.id || null);
        setMode(TimerMode.BREAK);
        setTimeLeft(5 * 60);
      } else {
        setMode(TimerMode.WORK);
        setTimeLeft(25 * 60);
      }
      setIsActive(false);
      try { new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3').play(); } catch(e){}
    }

    return () => clearInterval(interval);
  }, [isActive, timeLeft, mode, onSessionComplete, activeTask]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const totalTime = mode === TimerMode.WORK ? 25 * 60 : 5 * 60;
  const progress = ((totalTime - timeLeft) / totalTime) * 100;

  return (
    <div className="glass rounded-[2rem] p-8 flex flex-col items-center justify-center relative overflow-hidden border-white/5 shadow-2xl">
      <div className="absolute top-6 left-6 flex flex-col gap-1">
        <span className={`w-fit px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${mode === TimerMode.WORK ? 'bg-indigo-600 text-white' : 'bg-emerald-500 text-white'}`}>
          {mode} SESSION
        </span>
        {activeTask && mode === TimerMode.WORK && (
          <span className="text-[10px] text-slate-500 font-bold truncate max-w-[120px]">
            Target: {activeTask.title}
          </span>
        )}
      </div>
      
      <div className="relative flex items-center justify-center my-6">
        <svg className="w-56 h-56 transform -rotate-90">
          <circle
            className="text-slate-900"
            strokeWidth="6"
            stroke="currentColor"
            fill="transparent"
            r="90"
            cx="112"
            cy="112"
          />
          <circle
            className={`${mode === TimerMode.WORK ? 'text-indigo-500' : 'text-emerald-500'} transition-all duration-500`}
            strokeWidth="6"
            strokeDasharray={2 * Math.PI * 90}
            strokeDashoffset={2 * Math.PI * 90 * (1 - progress / 100)}
            strokeLinecap="round"
            stroke="currentColor"
            fill="transparent"
            r="90"
            cx="112"
            cy="112"
          />
        </svg>
        <div className="absolute flex flex-col items-center">
          <span className="text-5xl font-black font-mono tracking-tighter text-white">
            {formatTime(timeLeft)}
          </span>
          <span className="text-[10px] text-slate-500 font-bold tracking-[0.3em] mt-1">REMAINING</span>
        </div>
      </div>

      <div className="flex gap-3 w-full">
        <button 
          onClick={toggleTimer}
          className={`flex-1 py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-xl active:scale-95 ${isActive ? 'bg-slate-800 text-slate-400 border border-white/5' : 'bg-white text-slate-950 hover:bg-slate-200'}`}
        >
          {isActive ? 'Pause' : 'Start Focus'}
        </button>
        <button 
          onClick={resetTimer}
          className="px-6 rounded-2xl bg-slate-900 border border-white/5 hover:border-white/20 transition-all group"
        >
          <svg className="w-5 h-5 text-slate-500 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default Timer;
