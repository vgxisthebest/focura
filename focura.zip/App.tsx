
import React, { useState, useEffect } from 'react';
import Timer from './components/Timer';
import { Task, ProductivityStats } from './types';
import { getAISuggestions, getBestFocusTask, FocusRecommendation } from './services/geminiService';
import { supabase } from './services/supabase';
import { Auth } from './components/Auth';

const App: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskEnergy, setNewTaskEnergy] = useState<'low' | 'medium' | 'high'>('medium');
  const [isSuggesting, setIsSuggesting] = useState(false);
  const [isDeciding, setIsDeciding] = useState(false);
  const [recommendation, setRecommendation] = useState<FocusRecommendation | null>(null);
  const [aiUsageCount, setAiUsageCount] = useState(0);
  const [yesterdayScore, setYesterdayScore] = useState(0);
  const [plan, setPlan] = useState<'free' | 'pro'>('free');
  const [isFocusMode, setIsFocusMode] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session: realSession } }) => {
      if (realSession) {
        setSession(realSession);
      } else {
        const demoSession = localStorage.getItem('focura_demo_session');
        if (demoSession) setSession(JSON.parse(demoSession));
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, realSession) => {
      if (realSession) setSession(realSession);
    });
    
    return () => subscription.unsubscribe();
  }, []);

  // Sync Data from Supabase
  useEffect(() => {
    if (!session) return;
    const isDemo = session.user.id.startsWith('demo-user');

    const fetchData = async () => {
      if (isDemo) {
        const savedTasks = localStorage.getItem(`focura_tasks_${session.user.id}`);
        if (savedTasks) setTasks(JSON.parse(savedTasks));
        return;
      }

      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (!error && data) setTasks(data as Task[]);

      const { data: profile } = await supabase
        .from('profiles')
        .select('plan, ai_uses_today')
        .single();
      
      if (profile) {
        setPlan(profile.plan);
        setAiUsageCount(profile.ai_uses_today);
      }
    };

    fetchData();
  }, [session]);

  const [stats, setStats] = useState<ProductivityStats>({
    tasksCompleted: 0,
    focusSessions: 0,
    totalFocusMinutes: 0,
    dailyScore: 0
  });

  // Calculate stats
  useEffect(() => {
    if (!session) return;
    const completedTasksCount = tasks.filter(t => t.completed).length;
    const finalScore = (completedTasksCount * 10) + (stats.focusSessions * 15);
    setStats(prev => ({
      ...prev,
      tasksCompleted: completedTasksCount,
      dailyScore: finalScore
    }));
  }, [tasks, stats.focusSessions, session]);

  const handleUpgrade = async () => {
    setPlan('pro');
    if (!session.user.id.startsWith('demo-user')) {
      await supabase.from('profiles').update({ plan: 'pro' }).eq('id', session.user.id);
    }
    alert("PRO MODE ENGAGED.");
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    localStorage.removeItem('focura_demo_session');
    setSession(null);
    window.location.reload();
  };

  const addTask = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!newTaskTitle.trim()) return;

    const newTask: Partial<Task> = {
      user_id: session?.user?.id,
      title: newTaskTitle,
      completed: false,
      priority: 'medium',
      due_date: new Date().toISOString().split('T')[0],
      estimated_time: 25,
      energy_level: newTaskEnergy,
    };

    if (session.user.id.startsWith('demo-user')) {
      const demoTask = { ...newTask, id: crypto.randomUUID() } as Task;
      const updated = [demoTask, ...tasks];
      setTasks(updated);
      localStorage.setItem(`focura_tasks_${session.user.id}`, JSON.stringify(updated));
    } else {
      const { data, error } = await supabase.from('tasks').insert([newTask]).select().single();
      if (!error && data) setTasks([data, ...tasks]);
    }
    setNewTaskTitle('');
  };

  const toggleTask = async (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    const newState = !task.completed;
    
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: newState } : t));
    
    if (!session.user.id.startsWith('demo-user')) {
      await supabase.from('tasks').update({ completed: newState }).eq('id', id);
    }
  };

  const deleteTask = async (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    if (activeTaskId === id) setActiveTaskId(null);
    
    if (!session.user.id.startsWith('demo-user')) {
      await supabase.from('tasks').delete().eq('id', id);
    }
  };

  const handleAIPlanner = async () => {
    if (plan === 'free' && aiUsageCount >= 3) {
      alert("AI LIMIT REACHED. Upgrade to PRO.");
      return;
    }
    setIsSuggesting(true);
    const suggestions = await getAISuggestions(tasks);
    
    for (const s of suggestions) {
      const newTask = {
        user_id: session?.user?.id,
        title: s.title || 'Suggested Task',
        completed: false,
        priority: (s.priority as any) || 'medium',
        due_date: new Date().toISOString().split('T')[0],
        estimated_time: 30,
        energy_level: 'medium' as const,
      };

      if (!session.user.id.startsWith('demo-user')) {
        const { data } = await supabase.from('tasks').insert([newTask]).select().single();
        if (data) setTasks(prev => [data, ...prev]);
      } else {
        setTasks(prev => [{ ...newTask, id: crypto.randomUUID() } as Task, ...prev]);
      }
    }
    
    setIsSuggesting(false);
    setAiUsageCount(prev => prev + 1);
  };

  const handleAIDecision = async () => {
    if (plan === 'free' && aiUsageCount >= 3) return;
    setIsDeciding(true);
    const rec = await getBestFocusTask(tasks, newTaskEnergy, 60); 
    setRecommendation(rec);
    setIsDeciding(false);
    setAiUsageCount(prev => prev + 1);
  };

  const handleSessionComplete = async (duration: number, taskId: string | null) => {
    setStats(prev => ({
      ...prev,
      focusSessions: prev.focusSessions + 1,
      totalFocusMinutes: prev.totalFocusMinutes + duration
    }));

    if (!session.user.id.startsWith('demo-user')) {
      await supabase.from('focus_sessions').insert([{
        user_id: session.user.id,
        task_id: taskId,
        duration,
        completed: true
      }]);
    }

    if (isFocusMode) setIsFocusMode(false);
  };

  const activeTask = tasks.find(t => t.id === activeTaskId) || null;
  const recommendedTask = tasks.find(t => t.id === recommendation?.taskId);
  const isBetterThanYesterday = stats.dailyScore > yesterdayScore && yesterdayScore > 0;

  if (loading) return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center">
      <div className="w-12 h-12 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );

  if (!session) return <Auth />;

  if (isFocusMode) {
    return (
      <div className="min-h-screen bg-[#020617] flex flex-col items-center justify-center p-8 animate-in fade-in duration-1000">
        <div className="absolute top-0 left-0 w-full h-1 bg-white/5 overflow-hidden">
           <div className="h-full bg-indigo-500 animate-[scan_4s_linear_infinite]"></div>
        </div>
        <button 
          onClick={() => setIsFocusMode(false)}
          className="absolute top-12 left-12 text-slate-500 hover:text-white transition-all flex items-center gap-3 font-black text-[10px] uppercase tracking-[0.4em]"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 19l-7-7m0 0l7-7m-7 7h18" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Abort Mission
        </button>
        <div className="max-w-2xl w-full text-center space-y-16">
          <div className="space-y-4">
            <span className="text-indigo-500 text-[10px] font-black uppercase tracking-[0.6em] animate-pulse">Engaged Objective</span>
            <h1 className="text-5xl lg:text-7xl font-black tracking-tighter text-white leading-tight">
              {activeTask ? activeTask.title : "Pure Performance"}
            </h1>
          </div>
          <div className="scale-125 lg:scale-150">
            <Timer activeTask={activeTask} onSessionComplete={handleSessionComplete} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#020617] text-slate-100 p-6 lg:p-12 selection:bg-indigo-500/30">
      <div className="max-w-7xl mx-auto space-y-10">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center pb-8 border-b border-white/5 gap-6">
          <div className="flex items-center gap-6">
            <div className="relative">
              <h1 className="text-5xl font-black tracking-tighter focura-gradient italic">FOCURA</h1>
              <div className="absolute -bottom-1 left-0 w-full h-0.5 bg-indigo-500/20"></div>
            </div>
            {plan === 'pro' ? (
              <div className="bg-amber-500/10 border border-amber-500/20 text-amber-500 px-4 py-1.5 rounded-full text-[10px] font-black tracking-[0.2em] flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-amber-500 rounded-full shadow-[0_0_8px_#f59e0b]"></span>
                PRO ACTIVE
              </div>
            ) : (
               <div className="bg-slate-900 border border-white/5 text-slate-500 px-4 py-1.5 rounded-full text-[10px] font-black tracking-[0.2em]">
                FREE OPERATOR
              </div>
            )}
          </div>
          <div className="flex items-center gap-10">
            <div className="flex flex-col items-end">
              <span className="text-[10px] text-slate-600 font-black uppercase tracking-[0.3em] mb-1">Authenticated As</span>
              <span className="text-sm font-bold text-slate-300">{session.user.email}</span>
            </div>
            <button 
              onClick={handleSignOut}
              className="group p-3 rounded-2xl border border-white/5 hover:border-rose-500/30 transition-all bg-slate-900/50"
              title="Terminate Protocol"
            >
              <svg className="w-5 h-5 text-slate-500 group-hover:text-rose-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <aside className="lg:col-span-4 space-y-8">
            <div className="glass-heavy rounded-[3rem] p-10 border-indigo-500/20 shadow-2xl relative overflow-hidden group">
              <div className="absolute -right-16 -top-16 w-64 h-64 bg-indigo-600/10 blur-[100px] group-hover:bg-indigo-600/20 transition-all duration-1000"></div>
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-8">
                  <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">Daily Win Rate</h3>
                  <span className="text-[10px] font-mono text-indigo-400">CREDITS: {plan === 'pro' ? '∞' : `${3 - aiUsageCount}/3`}</span>
                </div>
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-[9rem] leading-none font-black tracking-tighter tabular-nums">{stats.dailyScore}</span>
                  {isBetterThanYesterday && <span className="text-emerald-400 font-black text-xs animate-bounce">🔥</span>}
                </div>
                <div className="w-full bg-slate-900/80 h-4 rounded-full mb-10 border border-white/5 overflow-hidden p-1">
                  <div className="h-full bg-gradient-to-r from-indigo-600 via-indigo-400 to-purple-600 rounded-full transition-all duration-1000" style={{ width: `${Math.min(100, stats.dailyScore)}%` }} />
                </div>
                <div className="grid grid-cols-2 gap-10 pt-4 border-t border-white/5">
                  <SidebarStat label="Wins" value={stats.tasksCompleted} suffix="tasks" />
                  <SidebarStat label="Cycles" value={stats.focusSessions} suffix="units" />
                </div>
              </div>
            </div>

            <div className="glass rounded-[3rem] p-10">
                 <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 mb-8">Focus Module</h3>
                 <Timer activeTask={activeTask} onSessionComplete={handleSessionComplete} />
                 {activeTask && (
                   <button onClick={() => setIsFocusMode(true)} className="w-full mt-8 py-5 rounded-2xl border border-white/5 hover:border-indigo-500/50 hover:bg-indigo-500/5 transition-all text-[10px] font-black uppercase tracking-[0.4em] text-slate-500">
                     Deploy Immersive Mode
                   </button>
                 )}
            </div>

            {plan === 'free' && (
              <div className="glass rounded-[2.5rem] p-8 border-amber-500/20 bg-amber-500/5 cursor-pointer group hover:bg-amber-500/10 transition-all" onClick={handleUpgrade}>
                <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-500 mb-2">Upgrade to Pro</h4>
                <p className="text-xs text-slate-400 mb-6 font-medium">Infinite AI Planner & Decision Engine.</p>
                <div className="flex justify-between text-amber-500 font-black text-[10px] tracking-widest uppercase">
                  <span>Start Now</span>
                  <span>$10 / Mo</span>
                </div>
              </div>
            )}
          </aside>

          <main className="lg:col-span-8">
            <div className="glass-heavy rounded-[3.5rem] p-12 h-full flex flex-col shadow-2xl relative min-h-[800px]">
              <div className="scanline opacity-10"></div>
              <div className="flex flex-wrap justify-between items-center gap-8 mb-12">
                <h2 className="text-4xl font-black tracking-tight">TACTICAL STREAM</h2>
                <div className="flex items-center gap-4">
                  <button onClick={handleAIDecision} disabled={isDeciding} className="bg-indigo-600 hover:bg-indigo-500 px-8 py-4 rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.3em] transition-all">
                    Next Move
                  </button>
                  <button onClick={handleAIPlanner} disabled={isSuggesting} className="bg-white hover:bg-slate-200 text-slate-950 px-8 py-4 rounded-[1.5rem] font-black text-[10px] uppercase tracking-[0.3em] transition-all">
                    AI Planner
                  </button>
                </div>
              </div>

              {recommendation && recommendedTask && (
                <div className="mb-12 p-8 rounded-[2.5rem] bg-indigo-600/5 border-2 border-indigo-500/20 animate-in slide-in-from-top-4">
                  <h4 className="text-2xl font-black mb-2">{recommendedTask.title}</h4>
                  <p className="text-sm text-slate-400 mb-6 italic">"{recommendation.reason}"</p>
                  <button onClick={() => { setActiveTaskId(recommendedTask.id); setRecommendation(null); setIsFocusMode(true); }} className="w-full bg-indigo-600 py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.4em]">
                    Initiate Deployment
                  </button>
                </div>
              )}

              <div className="bg-slate-900/40 rounded-[2.5rem] p-8 mb-12 border border-white/[0.03]">
                <form onSubmit={addTask} className="flex gap-6">
                  <input value={newTaskTitle} onChange={(e) => setNewTaskTitle(e.target.value)} placeholder="Identify next win..." className="flex-1 bg-transparent border-b-2 border-slate-800 pb-2 text-xl font-bold focus:outline-none focus:border-indigo-600 transition-all" />
                  <button type="submit" className="px-8 py-3 bg-white text-slate-950 rounded-xl font-black text-[10px] uppercase tracking-[0.4em]">Deploy</button>
                </form>
              </div>

              <div className="flex-1 space-y-5 overflow-y-auto custom-scrollbar pr-3">
                {tasks.map(task => (
                  <div key={task.id} className={`group relative flex items-center gap-8 p-8 rounded-[2.5rem] border-2 transition-all cursor-pointer ${activeTaskId === task.id ? 'bg-indigo-600/10 border-indigo-500/40' : 'bg-slate-900/30 border-white/[0.03] hover:border-white/10'} ${task.completed ? 'opacity-25' : ''}`}>
                    <button onClick={(e) => { e.stopPropagation(); toggleTask(task.id); }} className={`w-12 h-12 rounded-[1.25rem] border-2 flex items-center justify-center transition-all ${task.completed ? 'bg-emerald-500 border-emerald-500' : 'border-slate-800'}`}>
                      {task.completed && <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="4"><path d="M5 13l4 4L19 7" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                    </button>
                    <div className="flex-1 min-w-0" onClick={() => !task.completed && setActiveTaskId(task.id)}>
                      <h4 className={`text-xl font-bold truncate ${task.completed ? 'line-through' : ''}`}>{task.title}</h4>
                      <span className="text-[9px] font-black uppercase tracking-widest text-slate-600">{task.priority} Priority</span>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); deleteTask(task.id); }} className="opacity-0 group-hover:opacity-100 p-2 hover:text-rose-500">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

const SidebarStat = ({ label, value, suffix }: { label: string, value: number, suffix: string }) => (
  <div>
    <p className="text-[9px] font-black uppercase tracking-[0.3em] text-slate-600">{label}</p>
    <div className="flex items-baseline gap-1.5">
      <span className="text-4xl font-black text-white">{value}</span>
      <span className="text-[8px] font-bold uppercase text-slate-700">{suffix}</span>
    </div>
  </div>
);

export default App;
