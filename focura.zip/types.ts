
export interface Task {
  id: string;
  user_id?: string;
  title: string; // Updated to match SQL schema
  priority: 'low' | 'medium' | 'high';
  due_date: string | null;
  estimated_time: number; // in minutes
  energy_level: 'low' | 'medium' | 'high';
  completed: boolean;
  category?: string; // Optional as not in SQL but used in AI logic
  created_at?: string;
}

export interface FocusSession {
  id: string;
  user_id: string;
  task_id: string | null;
  duration: number;
  completed: boolean;
  date: string;
}

export interface ProductivityStats {
  tasksCompleted: number;
  focusSessions: number;
  totalFocusMinutes: number;
  dailyScore: number;
}

export enum TimerMode {
  WORK = 'WORK',
  BREAK = 'BREAK'
}
